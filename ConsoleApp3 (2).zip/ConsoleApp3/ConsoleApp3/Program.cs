﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value:" );
            string range = Console.ReadLine();
            string[] values = range.Split(',');
            int n1 = Convert.ToInt32(values[0]);
            int n2 = Convert.ToInt32(values[1]);          
            Console.WriteLine("Prime Numbers Between " + range + ":");
            var primeNoList = GetListOfPrimeNumbers(n1, n2);     
            foreach(var item in primeNoList)
            {              
                Console.WriteLine(item);               
            }
            
        }
        public static List<int> GetListOfPrimeNumbers(int n1,int n2)
        {
            List<int> primeNoList = new List<int>();
            for(int i=n1+1 ;i<n2;i++)
            {
                bool flag = true;

                if (i == 0 || i == 1)
                    flag = true;

                for (int j = 2; j <= i / 2; ++j)
                {                    
                    if (i % j == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if(flag)
                {
                    primeNoList.Add(i);
                }
            }

            return primeNoList;
        }
    }
}
