﻿using Assignment_2.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;
using System;

namespace Assignment_2.Repository
{
    public class PrimeRepository: IPrimeRepositary
    {
        string connectionString = "Data Source=sql.bsite.net\\MSSQL2016;User ID=priyasampledb_SampleDB;Password=12345678;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public async Task<List<int>> GetPrimeNoList(Int32 n1,Int32 n2)
        {
            List<int> primeNoList = new List<int>();
            for (int i = n1 + 1; i < n2; i++)
            {
                bool flag = true;

                if (i == 0 || i == 1)
                    flag = true;

                for (int j = 2; j <= i / 2; ++j)
                {
                    if (i % j == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    primeNoList.Add(i);
                }
            }
            return primeNoList;
        }
      
     
        public async Task<dynamic> Insert(PrimeModel values)
        {   
            try
            {
                using (var connect = new SqlConnection(connectionString))
                {
                    await connect.OpenAsync();
                    var query = @"INSERT INTO primeTable (inputRange,executionTime,nameOftheAlgorithm,countOfPrimeNumbers,createdOn)
                    VALUES (@inputRange,@executionTime,@nameOftheAlgorithm,@countOfPrimeNumbers,GetDate()) SELECT CAST(SCOPE_IDENTITY() as int)";
                    var result = await connect.QueryAsync(query, values);
                    return result;
                }
            }
              catch(Exception ex)
            {
                throw ex;
            }               

        }

        public async Task<dynamic> GetAllData()
        {
            try
            { 
                using (var connection = new SqlConnection(connectionString))
                {
                await connection.OpenAsync();
                var query = @"select * from primeTable";
                var result = await connection.QueryAsync<PrimeModel>(query);
                return result;
                }
            }
            catch (Exception ex)
            {
            throw ex;
            }

        }


    }
}
