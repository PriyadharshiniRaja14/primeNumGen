﻿using Assignment_2.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_2.Repository
{
    public interface IPrimeRepositary
    {
        public Task<List<int>> GetPrimeNoList(Int32 n1,Int32 n2);
        public Task<dynamic> GetAllData();
      

        public Task<dynamic> Insert(PrimeModel e);

        


    }
}
