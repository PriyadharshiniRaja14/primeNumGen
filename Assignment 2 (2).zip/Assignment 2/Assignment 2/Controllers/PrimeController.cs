﻿using Assignment_2.Entities;
using Assignment_2.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace Assignment_2.Controllers

{
    [Route("api/[controller]")]
    public class PrimeController:ControllerBase
    {
        private readonly IPrimeRepositary _IPRepo;
        public PrimeController(IPrimeRepositary IPRepo)
        {
            _IPRepo = IPRepo;
        }
        [HttpPost("getPrimeList")]
        public async Task<IActionResult> GetPrimeNoList(string value)
        {
            try
            {
                DateTime startTime = DateTime.Now;
                string[] values = value.Split(',');
                int n1 = Convert.ToInt32(values[0]);
                int n2 = Convert.ToInt32(values[1]);
                var GetListOfPrime = await _IPRepo.GetPrimeNoList(n1,n2); //method for getting PrimeNo list 
                TimeSpan endTime = DateTime.Now - startTime;
                var executionTime = endTime.ToString();
                PrimeModel prime = new PrimeModel()
                {                   
                    inputRange = value,
                    executionTime = executionTime,
                    nameOftheAlgorithm = "Md5",
                    countOfPrimeNumbers = GetListOfPrime.Count()
                };
                var result = await _IPRepo.Insert(prime);
                return StatusCode(200,GetListOfPrime);
            }
            catch (Exception ex)
            {              
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("getAllData")]
        public async Task<IActionResult> GetId()
        {
            try
            {
                var GetData = await _IPRepo.GetAllData();              
                return StatusCode(200, GetData);
            }
            catch (Exception ex)
            {               
                return StatusCode(500, ex.Message);
            }
        }
       


    }
}
