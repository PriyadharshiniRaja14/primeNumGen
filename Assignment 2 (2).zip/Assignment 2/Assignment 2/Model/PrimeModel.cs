﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_2.Entities
{
    public class PrimeModel
    {
        public int PrimeId { get; set; }
        public string executionTime { get; set; }
        public string inputRange { get; set; }
        public string nameOftheAlgorithm { get; set; }
        public int countOfPrimeNumbers { get; set; }

    }
}
